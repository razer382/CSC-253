﻿namespace WinUI
{


    partial class EmployeeDataSet
    {
    }
}

namespace WinUI.EmployeeDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
