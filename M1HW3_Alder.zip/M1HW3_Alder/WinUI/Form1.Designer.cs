﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.brakeButton = new System.Windows.Forms.Button();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.createCarButton = new System.Windows.Forms.Button();
            this.yearLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.entryGroupBox = new System.Windows.Forms.GroupBox();
            this.yearDetailLabel = new System.Windows.Forms.Label();
            this.detailsGroupBox = new System.Windows.Forms.GroupBox();
            this.makeDetailLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.yearText = new System.Windows.Forms.Label();
            this.makeText = new System.Windows.Forms.Label();
            this.speedText = new System.Windows.Forms.Label();
            this.entryGroupBox.SuspendLayout();
            this.detailsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(179, 239);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 38);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // brakeButton
            // 
            this.brakeButton.Location = new System.Drawing.Point(93, 254);
            this.brakeButton.Name = "brakeButton";
            this.brakeButton.Size = new System.Drawing.Size(75, 23);
            this.brakeButton.TabIndex = 1;
            this.brakeButton.Text = "Brake";
            this.brakeButton.UseVisualStyleBackColor = true;
            this.brakeButton.Click += new System.EventHandler(this.brakeButton_Click);
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(93, 225);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(75, 23);
            this.accelerateButton.TabIndex = 2;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // createCarButton
            // 
            this.createCarButton.Location = new System.Drawing.Point(12, 239);
            this.createCarButton.Name = "createCarButton";
            this.createCarButton.Size = new System.Drawing.Size(75, 38);
            this.createCarButton.TabIndex = 3;
            this.createCarButton.Text = "Create car object";
            this.createCarButton.UseVisualStyleBackColor = true;
            this.createCarButton.Click += new System.EventHandler(this.createCarButton_Click);
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(6, 16);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(32, 13);
            this.yearLabel.TabIndex = 4;
            this.yearLabel.Text = "Year:";
            // 
            // makeLabel
            // 
            this.makeLabel.AutoSize = true;
            this.makeLabel.Location = new System.Drawing.Point(6, 47);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(37, 13);
            this.makeLabel.TabIndex = 5;
            this.makeLabel.Text = "Make:";
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(41, 13);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 20);
            this.yearTextBox.TabIndex = 6;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(41, 44);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 20);
            this.makeTextBox.TabIndex = 7;
            // 
            // entryGroupBox
            // 
            this.entryGroupBox.Controls.Add(this.yearLabel);
            this.entryGroupBox.Controls.Add(this.makeTextBox);
            this.entryGroupBox.Controls.Add(this.yearTextBox);
            this.entryGroupBox.Controls.Add(this.makeLabel);
            this.entryGroupBox.Location = new System.Drawing.Point(27, 12);
            this.entryGroupBox.Name = "entryGroupBox";
            this.entryGroupBox.Size = new System.Drawing.Size(203, 78);
            this.entryGroupBox.TabIndex = 0;
            this.entryGroupBox.TabStop = false;
            this.entryGroupBox.Text = "Enter Details";
            // 
            // yearDetailLabel
            // 
            this.yearDetailLabel.AutoSize = true;
            this.yearDetailLabel.Location = new System.Drawing.Point(11, 16);
            this.yearDetailLabel.Name = "yearDetailLabel";
            this.yearDetailLabel.Size = new System.Drawing.Size(32, 13);
            this.yearDetailLabel.TabIndex = 8;
            this.yearDetailLabel.Text = "Year:";
            // 
            // detailsGroupBox
            // 
            this.detailsGroupBox.Controls.Add(this.speedText);
            this.detailsGroupBox.Controls.Add(this.makeText);
            this.detailsGroupBox.Controls.Add(this.yearText);
            this.detailsGroupBox.Controls.Add(this.speedLabel);
            this.detailsGroupBox.Controls.Add(this.makeDetailLabel);
            this.detailsGroupBox.Controls.Add(this.yearDetailLabel);
            this.detailsGroupBox.Location = new System.Drawing.Point(27, 97);
            this.detailsGroupBox.Name = "detailsGroupBox";
            this.detailsGroupBox.Size = new System.Drawing.Size(200, 99);
            this.detailsGroupBox.TabIndex = 9;
            this.detailsGroupBox.TabStop = false;
            this.detailsGroupBox.Text = "Car Details";
            // 
            // makeDetailLabel
            // 
            this.makeDetailLabel.AutoSize = true;
            this.makeDetailLabel.Location = new System.Drawing.Point(6, 41);
            this.makeDetailLabel.Name = "makeDetailLabel";
            this.makeDetailLabel.Size = new System.Drawing.Size(37, 13);
            this.makeDetailLabel.TabIndex = 8;
            this.makeDetailLabel.Text = "Make:";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(2, 68);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(41, 13);
            this.speedLabel.TabIndex = 9;
            this.speedLabel.Text = "Speed:";
            // 
            // yearText
            // 
            this.yearText.AutoSize = true;
            this.yearText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.yearText.Location = new System.Drawing.Point(49, 16);
            this.yearText.MinimumSize = new System.Drawing.Size(100, 20);
            this.yearText.Name = "yearText";
            this.yearText.Size = new System.Drawing.Size(100, 20);
            this.yearText.TabIndex = 10;
            // 
            // makeText
            // 
            this.makeText.AutoSize = true;
            this.makeText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.makeText.Location = new System.Drawing.Point(49, 41);
            this.makeText.MinimumSize = new System.Drawing.Size(100, 20);
            this.makeText.Name = "makeText";
            this.makeText.Size = new System.Drawing.Size(100, 20);
            this.makeText.TabIndex = 11;
            // 
            // speedText
            // 
            this.speedText.AutoSize = true;
            this.speedText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.speedText.Location = new System.Drawing.Point(49, 70);
            this.speedText.MinimumSize = new System.Drawing.Size(100, 20);
            this.speedText.Name = "speedText";
            this.speedText.Size = new System.Drawing.Size(100, 20);
            this.speedText.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(266, 292);
            this.Controls.Add(this.detailsGroupBox);
            this.Controls.Add(this.entryGroupBox);
            this.Controls.Add(this.createCarButton);
            this.Controls.Add(this.accelerateButton);
            this.Controls.Add(this.brakeButton);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Car Class";
            this.entryGroupBox.ResumeLayout(false);
            this.entryGroupBox.PerformLayout();
            this.detailsGroupBox.ResumeLayout(false);
            this.detailsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button brakeButton;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button createCarButton;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.GroupBox entryGroupBox;
        private System.Windows.Forms.Label yearDetailLabel;
        private System.Windows.Forms.GroupBox detailsGroupBox;
        private System.Windows.Forms.Label speedText;
        private System.Windows.Forms.Label makeText;
        private System.Windows.Forms.Label yearText;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label makeDetailLabel;
    }
}

