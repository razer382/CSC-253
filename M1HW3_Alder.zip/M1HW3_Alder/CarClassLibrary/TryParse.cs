﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarClassLibrary
{
    class TryParse
    {
        public static int ParseInt(TextBox box)
        {
            int value;

            if(int.TryParse(box.Text, out value))
            {
                return value;
            }
            else
            {
                MessageBox.Show("Error parsing year.");
                return 0;
            }
        }
    }
}
