﻿/**
* 9/20/2021 (Reused from previous homework)
* CSC 253
* Branden Alder
* Program that loads information from file into class
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassInfoLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes program
            this.Close();
        }

        private void readFileButton_Click(object sender, EventArgs e)
        {   // Creates person object from file and displays to labels
            Person person = new Person();

            ReadFromFile.ReadPersonFile(person);

            firstNameLabel.Text = person.FirstName;
            middleNameLabel.Text = person.MiddleName;
            lastNameLabel.Text = person.LastName;
            ageLabel.Text = person.Age.ToString();
        }
    }
}
