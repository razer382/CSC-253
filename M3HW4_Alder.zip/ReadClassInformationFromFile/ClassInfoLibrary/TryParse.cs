﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassInfoLibrary
{
    public class TryParse
    {
        public static int ParseInt(string input)
        {   // Parses int from string
            if(int.TryParse(input, out int num))
            {
                return num;
            }
            else
            {
                MessageBox.Show("Error parsing age.");
                return 0;
            }
        }
    }
}
