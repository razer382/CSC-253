﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace ClassInfoLibrary
{
    public class ReadFromFile
    {
        public static void ReadPersonFile(Person person)
        {   // Reads object info from file and adds to person props 
            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText("UserInformation.csv");

                while(!inputFile.EndOfStream)
                {
                    string line = inputFile.ReadLine();
                    string[] split = line.Split(',');

                    person.FirstName = split[0];
                    person.MiddleName = split[1];
                    person.LastName = split[2];
                    person.Age = TryParse.ParseInt(split[3]);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error reading file");
            }
        }

    }
}
