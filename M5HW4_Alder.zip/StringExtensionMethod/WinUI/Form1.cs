﻿/**
* 10/25/2021
* CSC 253
* Branden Alder
* Program that uses extension methods
*/
using System;
using System.Windows.Forms;
using static ExtensionLib.ExtensionMethods;
using System.Linq;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Converts to char array then displays it to ListBoxq
            char[] charArray = stringTextBox.Text.ConvertToCharArray();
            foreach (var item in charArray)
            {
                charArrayListBox.Items.Add(item);
            }

            // Put date into label in EU format
            string[] dateArray = dateTextBox.Text.GetDateArray();
            dateLabel.Text = $"{dateArray[1]}/{dateArray[0]}/{dateArray[2]}";

            // Show formatted phone number
            phoneNumberLabel.Text = phoneNumberTextBox.Text.FormatPhoneNumber();

            // show backwards string
            backwardsLabel.Text = stringTextBox.Text.GetStringBackwards();

            // Display word count
            wordCountLabel.Text = stringTextBox.Text.CountWords().ToString();
        }
    }
}
