﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionLib
{
    public static class ExtensionMethods
    {
        public static char[] ConvertToCharArray(this string input)
        {
            return input.ToCharArray();
        }

        public static string[] GetDateArray(this string input)
        {
            return input.Split('/');
        }

        public static string FormatPhoneNumber(this string input) 
        {
            input = input.Insert(0, "(");
            input = input.Insert(4, ")");
            input = input.Insert(8, "-");
            return input;
        }

        public static string GetStringBackwards(this string input)
        {
            char[] arr = input.ToCharArray();
            string s = "";

            for (int i = arr.Length - 1; i >= 0; i--)
            {
                s += arr[i].ToString();
            }

            return s;
        }

        public static int CountWords(this string input)
        {
            return input.Split(' ').Length;
        }
    }
}
