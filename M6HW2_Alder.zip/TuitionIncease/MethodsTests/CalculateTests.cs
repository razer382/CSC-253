﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Methods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods.Tests
{
    [TestClass()]
    public class CalculateTests
    {
        [TestMethod()]
        public void CalculateTuitionIncreaseTest()
        {
            decimal tuition = 10000;
            double percentage = 10;
            decimal expected = 11000;


            decimal actual = tuition +  Calculate.CalculateTuitionIncrease(tuition, percentage);

            Assert.AreEqual(actual, expected);
        }
    }
}