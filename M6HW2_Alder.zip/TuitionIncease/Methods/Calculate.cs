﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods
{
    public static class Calculate
    {
        public static decimal CalculateTuitionIncrease(decimal tuition, double percentage)
        {
            return tuition * ((decimal)percentage / 100);
        }
    }
}
