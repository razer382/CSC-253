﻿/**
* 11/9/2021
* CSC 253
* Branden Alder
* Program adding Unit tests to tuition program from CSC-153
*/

using System;
using System.Windows.Forms;
using Methods;

namespace WinUIi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {   // Puts tuition in listbox for each year where its increased. 
            decimal tuition = TryParse.ParseDecimal(tuitionTextBox.Text);
            for (int i = 1; i < 6; i++)
            {
                tuition += Calculate.CalculateTuitionIncrease(tuition, TryParse.ParseDouble(percentageTextBox.Text));
                tuitionListBox.Items.Add($"Tuition after {i} year(s): {tuition.ToString("c")}");
            }
        }
    }
}
