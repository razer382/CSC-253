﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CalculatorLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary.Tests
{
    [TestClass()]
    public class CalculateTests
    {
        // Basic unit test
        [TestMethod()]
        public void CalculateRetailTest()
        {
            // Arrange
            double markup = .50;
            decimal wholeSale = 1.00m;
            decimal expected = 1.50m;

            // Act
            decimal actual = Calculate.CalculateRetail(wholeSale, markup);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void CalculateRetailTest_Two()
        {
            // Arrange
            decimal wholeSale = 5.00m;
            decimal expected = 6.85m;
            double markup = .37;

            // Act
            decimal actual = Calculate.CalculateRetail(wholeSale, markup);

            // Assert
            Assert.AreEqual(expected, actual);
            
        }
    }
}