﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorLibrary
{
    public static class TryParse
    {
        public static double ParseDouble(string input)
        {
            if(double.TryParse(input, out double d))
            {
                return d;
            }
            else
            {
                MessageBox.Show("Couldn't parse markup percentage. Check input and try again!");
                return -1;
            }
        }

        public static decimal ParseDecimal(string input)
        {
            if(decimal.TryParse(input, out decimal d))
            {
                return d;
            }
            else
            {
                MessageBox.Show("Couldn't parse whole sale price. Check input and try again!");
                return -1;
            }
        }
    }
}
