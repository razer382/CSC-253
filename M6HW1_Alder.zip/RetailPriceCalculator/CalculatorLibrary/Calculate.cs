﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
    public static class Calculate
    {
        public static decimal CalculateRetail(decimal retailPrice, double markup)
        {       
            return (retailPrice + (retailPrice * (decimal)markup));
        }
    }
}