﻿/**
* 11/8/2021
* CSC 253
* Branden Alder
* Program that adds unit testing to the retail price calculator we did in CSC-153
*/

using System;
using System.Windows.Forms;
using CalculatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {   // Calculates retail price and puts in label
            retailPriceLabel.Text = Calculate.CalculateRetail(TryParse.ParseDecimal(wholesaleTextBox.Text), TryParse.ParseDouble(markupTextBox.Text)).ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes program
            this.Close();
        }
    }
}
