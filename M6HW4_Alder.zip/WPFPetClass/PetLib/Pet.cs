﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetLib
{
    public class Pet
    {
        public Pet()
        {
            Name = "";
            Type = "";
            Age = 0;
        }
        public Pet(string name, string type, int age)
        {
            Name = name;
            Type = type;
            Age = age;
        }

        public string Name { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}\n" +
                   $"Type: {Type}\n" +
                   $"Age: {Age}";
        }
    }
}
