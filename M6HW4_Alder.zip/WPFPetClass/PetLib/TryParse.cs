﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PetLib
{
    public static class TryParse
    {
        public static int ParseInteger(string input)
        {
            if(int.TryParse(input, out int i))
            {
                return i;
            }
            else
            {
                MessageBox.Show("Error parsing pet age. Check input and try again.");
                return -1;
            }
        }
    }
}
