﻿/*
 * Branden Alder
 * CSC 253 
 * 11/15/2021
 * WPF of pet class assignment from 153
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetLib;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, RoutedEventArgs e)
        {   // Displays a message box with pet info
            
            if(!String.IsNullOrWhiteSpace(nameTextBox.Text) && !String.IsNullOrWhiteSpace(typeTextBox.Text) && !String.IsNullOrWhiteSpace(ageTextBox.Text))
            {
                MessageBox.Show(new Pet(nameTextBox.Text, typeTextBox.Text, TryParse.ParseInteger(ageTextBox.Text)).ToString(), "YOUR PET!");
            }
            else
            {
                MessageBox.Show("Check input and try again.", "ERROR");
            }
        }


    }
}
