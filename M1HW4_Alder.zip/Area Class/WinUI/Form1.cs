﻿/**
* 8/26/2021
* CSC 253
* Branden Alder
* Program calculating the area of 3 different shapes.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AreaClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes program
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {   // Parses input and displays area 
            double radius, height;
            int width, length;

            if(circleRadioButton.Checked)
            {
                radius = TryParse.ParseDouble(radiusTextBox);
                areaLabelText.Text = Area.CalculateArea(radius).ToString("n2");
            }
            else if (rectangleRadioButton.Checked)
            {
                width = TryParse.ParseInt(widthTextBox);
                length = TryParse.ParseInt(lengthTextBox);
                areaLabelText.Text = Area.CalculateArea(width, length).ToString("");
            }
            else if(cylinderRadioButton.Checked)
            {
                radius = TryParse.ParseDouble(radiusTextBox);
                height = TryParse.ParseDouble(heightTextBox);
                areaLabelText.Text = Area.CalculateArea(radius, height).ToString("n2");
            }
        }

        private void cylinderRadioButton_CheckedChanged(object sender, EventArgs e)
        {   // Hides components that aren't needed
            widthLabel.Visible = false;
            widthTextBox.Visible = false;

            lengthLabel.Visible = false;
            widthTextBox.Visible = false;

            // Restore needed components
            radiusLabel.Visible = true;
            radiusTextBox.Visible = true;

            heightLabel.Visible = true;
            heightTextBox.Visible = true;

        }

        private void circleRadioButton_CheckedChanged(object sender, EventArgs e)
        {   // Hides components that aren't needed
            widthLabel.Visible = false;
            widthTextBox.Visible = false;

            lengthLabel.Visible = false;
            lengthTextBox.Visible = false;

            heightLabel.Visible = false;
            heightTextBox.Visible = false;

            // Restore needed components
            radiusLabel.Visible = true;
            radiusTextBox.Visible = true;

        }

        private void rectangleRadioButton_CheckedChanged(object sender, EventArgs e)
        {   // Hides components that aren't needed
            radiusLabel.Visible = false;
            radiusTextBox.Visible = false;

            heightLabel.Visible = false;
            heightTextBox.Visible = false;

            // Restore needed components
            widthLabel.Visible = true;
            widthTextBox.Visible = true;

            lengthLabel.Visible = true;
            lengthTextBox.Visible = true;

        }
    }
}
