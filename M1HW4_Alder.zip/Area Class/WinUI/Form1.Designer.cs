﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.circleRadioButton = new System.Windows.Forms.RadioButton();
            this.radioGroupBox = new System.Windows.Forms.GroupBox();
            this.rectangleRadioButton = new System.Windows.Forms.RadioButton();
            this.cylinderRadioButton = new System.Windows.Forms.RadioButton();
            this.entryGroupBox = new System.Windows.Forms.GroupBox();
            this.radiusLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.radiusTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.areaLabel = new System.Windows.Forms.Label();
            this.areaLabelText = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.radioGroupBox.SuspendLayout();
            this.entryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // circleRadioButton
            // 
            this.circleRadioButton.AutoSize = true;
            this.circleRadioButton.Location = new System.Drawing.Point(6, 19);
            this.circleRadioButton.Name = "circleRadioButton";
            this.circleRadioButton.Size = new System.Drawing.Size(142, 17);
            this.circleRadioButton.TabIndex = 0;
            this.circleRadioButton.TabStop = true;
            this.circleRadioButton.Text = "Calculate area of a circle";
            this.circleRadioButton.UseVisualStyleBackColor = true;
            this.circleRadioButton.CheckedChanged += new System.EventHandler(this.circleRadioButton_CheckedChanged);
            // 
            // radioGroupBox
            // 
            this.radioGroupBox.Controls.Add(this.cylinderRadioButton);
            this.radioGroupBox.Controls.Add(this.rectangleRadioButton);
            this.radioGroupBox.Controls.Add(this.circleRadioButton);
            this.radioGroupBox.Location = new System.Drawing.Point(13, 13);
            this.radioGroupBox.Name = "radioGroupBox";
            this.radioGroupBox.Size = new System.Drawing.Size(200, 100);
            this.radioGroupBox.TabIndex = 1;
            this.radioGroupBox.TabStop = false;
            this.radioGroupBox.Text = "Choose one";
            // 
            // rectangleRadioButton
            // 
            this.rectangleRadioButton.AutoSize = true;
            this.rectangleRadioButton.Location = new System.Drawing.Point(6, 42);
            this.rectangleRadioButton.Name = "rectangleRadioButton";
            this.rectangleRadioButton.Size = new System.Drawing.Size(161, 17);
            this.rectangleRadioButton.TabIndex = 1;
            this.rectangleRadioButton.TabStop = true;
            this.rectangleRadioButton.Text = "Calculate area of a rectangle";
            this.rectangleRadioButton.UseVisualStyleBackColor = true;
            this.rectangleRadioButton.CheckedChanged += new System.EventHandler(this.rectangleRadioButton_CheckedChanged);
            // 
            // cylinderRadioButton
            // 
            this.cylinderRadioButton.AutoSize = true;
            this.cylinderRadioButton.Location = new System.Drawing.Point(6, 65);
            this.cylinderRadioButton.Name = "cylinderRadioButton";
            this.cylinderRadioButton.Size = new System.Drawing.Size(153, 17);
            this.cylinderRadioButton.TabIndex = 2;
            this.cylinderRadioButton.TabStop = true;
            this.cylinderRadioButton.Text = "Calculate area of a cylinder";
            this.cylinderRadioButton.UseVisualStyleBackColor = true;
            this.cylinderRadioButton.CheckedChanged += new System.EventHandler(this.cylinderRadioButton_CheckedChanged);
            // 
            // entryGroupBox
            // 
            this.entryGroupBox.Controls.Add(this.heightTextBox);
            this.entryGroupBox.Controls.Add(this.lengthTextBox);
            this.entryGroupBox.Controls.Add(this.widthTextBox);
            this.entryGroupBox.Controls.Add(this.radiusTextBox);
            this.entryGroupBox.Controls.Add(this.heightLabel);
            this.entryGroupBox.Controls.Add(this.lengthLabel);
            this.entryGroupBox.Controls.Add(this.widthLabel);
            this.entryGroupBox.Controls.Add(this.radiusLabel);
            this.entryGroupBox.Location = new System.Drawing.Point(13, 120);
            this.entryGroupBox.Name = "entryGroupBox";
            this.entryGroupBox.Size = new System.Drawing.Size(200, 73);
            this.entryGroupBox.TabIndex = 2;
            this.entryGroupBox.TabStop = false;
            this.entryGroupBox.Text = "Enter numbers";
            // 
            // radiusLabel
            // 
            this.radiusLabel.AutoSize = true;
            this.radiusLabel.Location = new System.Drawing.Point(6, 16);
            this.radiusLabel.Name = "radiusLabel";
            this.radiusLabel.Size = new System.Drawing.Size(43, 13);
            this.radiusLabel.TabIndex = 0;
            this.radiusLabel.Text = "Radius:";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Location = new System.Drawing.Point(6, 16);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(38, 13);
            this.widthLabel.TabIndex = 1;
            this.widthLabel.Text = "Width:";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(6, 38);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(43, 13);
            this.lengthLabel.TabIndex = 2;
            this.lengthLabel.Text = "Length:";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(3, 38);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(41, 13);
            this.heightLabel.TabIndex = 3;
            this.heightLabel.Text = "Height:";
            // 
            // radiusTextBox
            // 
            this.radiusTextBox.Location = new System.Drawing.Point(56, 16);
            this.radiusTextBox.Name = "radiusTextBox";
            this.radiusTextBox.Size = new System.Drawing.Size(100, 20);
            this.radiusTextBox.TabIndex = 4;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(56, 16);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(100, 20);
            this.widthTextBox.TabIndex = 5;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(56, 38);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(100, 20);
            this.lengthTextBox.TabIndex = 6;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(56, 38);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 20);
            this.heightTextBox.TabIndex = 7;
            // 
            // areaLabel
            // 
            this.areaLabel.AutoSize = true;
            this.areaLabel.Location = new System.Drawing.Point(30, 211);
            this.areaLabel.Name = "areaLabel";
            this.areaLabel.Size = new System.Drawing.Size(32, 13);
            this.areaLabel.TabIndex = 3;
            this.areaLabel.Text = "Area:";
            // 
            // areaLabelText
            // 
            this.areaLabelText.AutoSize = true;
            this.areaLabelText.BackColor = System.Drawing.SystemColors.ControlLight;
            this.areaLabelText.Location = new System.Drawing.Point(66, 204);
            this.areaLabelText.MinimumSize = new System.Drawing.Size(100, 20);
            this.areaLabelText.Name = "areaLabelText";
            this.areaLabelText.Size = new System.Drawing.Size(100, 20);
            this.areaLabelText.TabIndex = 4;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(135, 267);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(79, 38);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(22, 267);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(79, 38);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate Area";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(226, 317);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.areaLabelText);
            this.Controls.Add(this.areaLabel);
            this.Controls.Add(this.entryGroupBox);
            this.Controls.Add(this.radioGroupBox);
            this.Name = "Form1";
            this.Text = "Area Class";
            this.radioGroupBox.ResumeLayout(false);
            this.radioGroupBox.PerformLayout();
            this.entryGroupBox.ResumeLayout(false);
            this.entryGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton circleRadioButton;
        private System.Windows.Forms.GroupBox radioGroupBox;
        private System.Windows.Forms.RadioButton rectangleRadioButton;
        private System.Windows.Forms.RadioButton cylinderRadioButton;
        private System.Windows.Forms.GroupBox entryGroupBox;
        private System.Windows.Forms.Label radiusLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.TextBox radiusTextBox;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.Label areaLabel;
        private System.Windows.Forms.Label areaLabelText;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
    }
}

