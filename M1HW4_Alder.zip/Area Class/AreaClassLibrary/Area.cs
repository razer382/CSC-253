﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public class Area
    {
        public static double CalculateArea(double radius)
        {   // Calculates area of a circle
            return Math.PI * (Math.Pow(radius, 2));
        }

        public static double CalculateArea(int width, int length)
        {   // Calculates area of a rectangle
            return width * length;
        }

        public static double CalculateArea(double radius, double height)
        {   // Calculates area of a cylinder
            return Math.PI * (Math.Pow(radius, 2)) * height;
        }
    }
}
