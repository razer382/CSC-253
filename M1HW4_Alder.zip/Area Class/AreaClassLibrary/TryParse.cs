﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaClassLibrary
{
    public class TryParse
    {
        public static double ParseDouble(TextBox box)
        {   // Parses double
            if(double.TryParse(box.Text, out double d))
            {
                return d;
            }
            else
            {
                MessageBox.Show("Error parsing your input.");
                return -1;
            }
        }

        public static int ParseInt(TextBox box)
        {   // Parses int
            if(int.TryParse(box.Text, out int i))
            {
                return i;
            }
            else
            {
                MessageBox.Show("Error parsing your input.");
                return -1;
            }
        }
    }
}
