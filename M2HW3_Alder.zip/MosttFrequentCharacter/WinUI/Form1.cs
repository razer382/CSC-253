﻿/**
* 9/23/2021
* CSC 253
* Branden Alder
* Program getting most frequent char in a string
*/
using System;
using System.Windows.Forms;
using StringManipLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes program
            this.Close();
        }

        private void mostFrequentCharButton_Click(object sender, EventArgs e)
        { // Assigns most frequent char to text label
            mostFrequentLabelText.Text = StringMethods.GetMostCommonCharacter(entryTextBox.Text);
        }
    }
}
