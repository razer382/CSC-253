﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringManipLibrary
{
    public static class StringMethods
    {
        
        // Method to get the most common character.
        public static string GetMostCommonCharacter(string input)
        {
            int count = 0;
            List<int> alphaCount = new List<int>();
            char[] alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] inputArray = input.ToCharArray();

            for (int i = 0; i < alphabet.Length; i++)
            {
                for (int j = 0; j < input.Length; j++)
                {
                    if (alphabet[i] == inputArray[j])
                    {
                        count++;
                    }
                }
                alphaCount.Add(count);
                count = 0;
            }
          
            return alphabet[alphaCount.IndexOf(alphaCount.Max())].ToString();
        }
    }
}
