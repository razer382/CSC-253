﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCounterLibrary
{
    public class StringManip
    {

        public static int CountWords(TextBox box)
        {   // Counts words in a text box using space delimiter and returns count
            string[] words = box.Text.Split(' ');
            return words.Length;
        }

        public static double GetAverage(TextBox box)
        {   // Gets average number of letters per word in the input provided
            double total = 0;

            string[] words = box.Text.Split(' ');
            foreach (var word in words)
            {
                total += word.Length; 
            }
            return total = total / words.Length;
        }
    }
}
