﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCounterLibrary
{
    public class StringManip
    {

        public static int CountWords(TextBox box)
        {   // Counts words in a text box using space delimiter and returns count
            string[] words = box.Text.Split(' ');
            return words.Length;
        }
    }
}
