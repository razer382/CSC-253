﻿/**
* 9/4/2021
* CSC 253
* Branden Alder 
* Program returning the number of words in a user's input
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordCounterLibrary;

namespace WinUI
{ 
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes program
            this.Close();
        }

        private void countWordsButton_Click(object sender, EventArgs e)
        {   // Calls CountWords on entry text box and outputs count to countlabeltext 
            countLabelText.Text = StringManip.CountWords(entryTextBox).ToString();
        }
    }
}
