﻿/**
* 9/13/2021
* CSC 253
* Branden Alder
* Program that writes a specified number of random numbers to a file
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FileWriterLibrary;
using System.IO;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes app
            this.Close();
        }

        private void writeToFileButton_Click(object sender, EventArgs e)
        {
            // Create random
            Random rand = new Random();

            // Create output file
            StreamWriter outputFile;
            outputFile = File.CreateText("numbers.txt");

            // Parse num from textbox
            int num = TryParse.ParseInt(numberTextBox);

            // If there wasn't an error parsing the number write to file
            if (num != -1)
            {
                try
                {
                    for (int i = 0; i < num; i++)
                    {
                        outputFile.WriteLine(rand.Next(100) + 1);
                    }

                    MessageBox.Show("Written to file");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            // Closes output file
            outputFile.Close();
        }
    }
}
