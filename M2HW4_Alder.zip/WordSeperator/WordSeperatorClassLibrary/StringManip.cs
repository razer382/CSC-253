﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordSeperatorClassLibrary
{
    public class StringManip
    {
        public static string SeparateString(string input)
        {   // Method to separate words

            char[] str = input.ToCharArray();
            string newString = String.Empty;

            for (int i = 0; i < str.Length; i++)
            {
                if(i > 0 & char.IsUpper(str[i]))
                {
                    newString += " " + str[i].ToString().ToLower();
                }
                else
                {
                    newString += str[i].ToString();
                }

            }
            return newString;
        }
    }
}