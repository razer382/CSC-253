﻿/**
* 9/10/2021
* CSC 253
* Branden Alder
* Program that takes words run together and seperates them based off of punctuation
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordSeperatorClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes application
            this.Close();
        }

        private void fixStringButton_Click(object sender, EventArgs e)
        {   // Pulls text from entery text box, separates words and puts in fixed string label
            fixedStringLabelText.Text = StringManip.SeparateString(entryTextBox.Text);
        }
    }
}
