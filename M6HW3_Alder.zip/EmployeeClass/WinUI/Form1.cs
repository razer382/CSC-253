﻿/**
* 11/15/2021
* CSC 253
* Branden Alder
* Employee winform from 153
*/
using System;
using System.Windows.Forms;
using EmployeeLib;

namespace WinUI
{
    public partial class Form1 : Form
    {
        private Employee e1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
        private Employee e2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
        private Employee e3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   // Adds employees to ListView using method in employee class
            employeeListView.Items.Add(new ListViewItem(e1.GetEmployeeRow()));
            employeeListView.Items.Add(new ListViewItem(e2.GetEmployeeRow()));
            employeeListView.Items.Add(new ListViewItem(e3.GetEmployeeRow()));
        }

        private void exitButton_Click(object sender, EventArgs e)
        { // Closes app
            this.Close();
        }
    }
}
