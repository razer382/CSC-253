﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employee
    {
        public Employee()
        {
            Name = "";
            IdNumber = 0;
            Department = "";
            Position = "";
        }
        public Employee(string name, int num, string department, string position)
        {
            Name = name;
            IdNumber = num;
            Department = department;
            Position = position;
        }

        public Employee(string name, int num)
        {
            Name = name;
            IdNumber = num;
            Department = "";
            Position = "";
        }

        public string Name { get; set; }
        public int IdNumber { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }

        // returns string array for row of listview
        public string[] GetEmployeeRow()
        {
            return new string[] {Name, IdNumber.ToString(), Department, Position };
        }

    }
}
