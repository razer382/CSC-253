﻿/**
* 10/18/2021
* CSC 253
* Branden Alder
* Program demonstrating inheritance
*/

using System;
using System.Windows.Forms;
using EmployeeLib;

namespace WinUI
{
    public partial class Form1 : Form
    {
        ProductionWorker worker = new ProductionWorker();

        public Form1()
        {
            InitializeComponent();
        }

        // Stores input into object and displays in label
        private void displayButton_Click(object sender, EventArgs e)
        {
                worker.Name = employeeNameTextBox.Text;
                worker.Number = TryParse.ParseInt(employeeNumberTextBox.Text);
                worker.HourlyRate = TryParse.ParseDecimal(hourlyPayRateTextBox.Text);
                outputLabel.Text = worker.ToString();
        }

        // Sets worker shift to day shift
        private void dayShiftRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if(dayShiftRadioButton.Checked)
            {
                worker.ShiftNumber = 1;
            }
        }

        // Sets worker shift to night shift
        private void nightShiftRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if(nightShiftRadioButton.Checked)
            {
                worker.ShiftNumber = 2;
            }
        }
    }
}
