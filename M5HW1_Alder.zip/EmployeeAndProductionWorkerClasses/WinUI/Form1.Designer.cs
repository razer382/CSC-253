﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shiftNumberGroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.dayShiftRadioButton = new System.Windows.Forms.RadioButton();
            this.nightShiftRadioButton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.hourlyPayRateTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.shiftNumberGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // shiftNumberGroupBox
            // 
            this.shiftNumberGroupBox.Controls.Add(this.nightShiftRadioButton);
            this.shiftNumberGroupBox.Controls.Add(this.dayShiftRadioButton);
            this.shiftNumberGroupBox.Location = new System.Drawing.Point(15, 74);
            this.shiftNumberGroupBox.Name = "shiftNumberGroupBox";
            this.shiftNumberGroupBox.Size = new System.Drawing.Size(282, 58);
            this.shiftNumberGroupBox.TabIndex = 0;
            this.shiftNumberGroupBox.TabStop = false;
            this.shiftNumberGroupBox.Text = "Shift Number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Employee Number:";
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(121, 10);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(176, 20);
            this.employeeNameTextBox.TabIndex = 3;
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(121, 39);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(176, 20);
            this.employeeNumberTextBox.TabIndex = 4;
            // 
            // dayShiftRadioButton
            // 
            this.dayShiftRadioButton.AutoSize = true;
            this.dayShiftRadioButton.Location = new System.Drawing.Point(106, 20);
            this.dayShiftRadioButton.Name = "dayShiftRadioButton";
            this.dayShiftRadioButton.Size = new System.Drawing.Size(59, 17);
            this.dayShiftRadioButton.TabIndex = 0;
            this.dayShiftRadioButton.TabStop = true;
            this.dayShiftRadioButton.Text = "Day (1)";
            this.dayShiftRadioButton.UseVisualStyleBackColor = true;
            this.dayShiftRadioButton.CheckedChanged += new System.EventHandler(this.dayShiftRadioButton_CheckedChanged);
            // 
            // nightShiftRadioButton
            // 
            this.nightShiftRadioButton.AutoSize = true;
            this.nightShiftRadioButton.Location = new System.Drawing.Point(183, 20);
            this.nightShiftRadioButton.Name = "nightShiftRadioButton";
            this.nightShiftRadioButton.Size = new System.Drawing.Size(65, 17);
            this.nightShiftRadioButton.TabIndex = 1;
            this.nightShiftRadioButton.TabStop = true;
            this.nightShiftRadioButton.Text = "Night (2)";
            this.nightShiftRadioButton.UseVisualStyleBackColor = true;
            this.nightShiftRadioButton.CheckedChanged += new System.EventHandler(this.nightShiftRadioButton_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Hourly Pay Rate: $";
            // 
            // hourlyPayRateTextBox
            // 
            this.hourlyPayRateTextBox.Location = new System.Drawing.Point(121, 156);
            this.hourlyPayRateTextBox.Name = "hourlyPayRateTextBox";
            this.hourlyPayRateTextBox.Size = new System.Drawing.Size(176, 20);
            this.hourlyPayRateTextBox.TabIndex = 6;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(222, 191);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 7;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(17, 228);
            this.outputLabel.MinimumSize = new System.Drawing.Size(280, 100);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(280, 100);
            this.outputLabel.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(313, 349);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.hourlyPayRateTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.employeeNumberTextBox);
            this.Controls.Add(this.employeeNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shiftNumberGroupBox);
            this.Name = "Form1";
            this.Text = "Employee and Production Worker";
            this.shiftNumberGroupBox.ResumeLayout(false);
            this.shiftNumberGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox shiftNumberGroupBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.RadioButton nightShiftRadioButton;
        private System.Windows.Forms.RadioButton dayShiftRadioButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox hourlyPayRateTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label outputLabel;
    }
}

