﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class ProductionWorker : Employee
    {
        public int ShiftNumber { get; set; }
        public decimal HourlyRate { get; set; }

        // Default constructor
        public ProductionWorker()
        {
            ShiftNumber = 0;
            HourlyRate = 0;
        }

        // Parameterized constructor
        public ProductionWorker(string name, int number, int shift, decimal payRate) : base(name, number)
        {
            ShiftNumber = shift;
            HourlyRate = payRate;
        }

        // ToString override of object to clean up display button
        public override string ToString()
        {
            return "Employee Name: " + Name
                 + "\nEmployee Number: " + Number
                 + "\nShift Number: " + ShiftNumber
                 + "\nHourly pay rate: " + HourlyRate.ToString("c");
        }
    }
}
