﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeLib
{
    public static class TryParse
    {
        //  Parses int from a string
        public static int ParseInt(string input)
        {
            if(int.TryParse(input, out int num))
            {
                return num;
            }
            else
            {
                MessageBox.Show("Error parsing employee number. Check input and try again.");
                return -1;
            }
        }

        // Parses decimal from string
        public static decimal ParseDecimal(string input)
        {
            if(decimal.TryParse(input, out decimal d))
            {
                return d;
            }
            else
            {
                MessageBox.Show("Error parsing pay rate. Check input and try again.");
                return -1;
            }
        }
    }
}
