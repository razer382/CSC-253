﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employee
    {
        public string Name { get; set; }
        public int Number { get; set; }

        // Default Constructor
        public Employee() 
        {   
            Name = "";
            Number = 0;
        }

        // Parameterized constructor
        public Employee(string name, int num) 
        {
            Name = name;
            Number = num;
        }
    }

    
}
