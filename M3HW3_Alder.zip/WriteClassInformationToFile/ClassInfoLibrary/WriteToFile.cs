﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassInfoLibrary
{
    public static class WriteToFile
    {
        public static void WritePersonToFile(Person person)
        {
            try
            {   // Creates file and writes class info. Shows message box then closes file
                StreamWriter outputFile;
                outputFile = File.CreateText("UserInformation.csv");

                outputFile.WriteLine($"{person.FirstName},{person.MiddleName},{person.LastName},{person.Age}");

                MessageBox.Show("Written to file.");
                outputFile.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error writing to file.");
            }
        }
    }
}
