﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassInfoLibrary
{
    public class TryParse
    {
        public static int ParseInt(TextBox box)
        {   // Parses int from textbox
            if(int.TryParse(box.Text, out int num))
            {
                return num;
            }
            else
            {
                MessageBox.Show("Error parsing age.");
                return 0;
            }
        }
    }
}
