﻿/**
* 9/15/2021
* CSC 253
* Branden Alder
* Program that reads a text file, displays numbers in list box and outputs total numbers in file
*/


using System;
using System.Windows.Forms;
using System.IO;
using FileReaderLib;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {   // Closes app
            this.Close();
        }

        private void readFileButton_Click(object sender, EventArgs e)
        {
            int total = 0, numOfNumbers = 0; int temp;

            try
            {   
                // Opens text file
                StreamReader inputFile;
                inputFile = File.OpenText("numbers.txt");

                while(!inputFile.EndOfStream)
                {   
                    // Parses int from file, adds to listbox and accumulators
                    temp = TryParse.ParseInteger(inputFile.ReadLine());
                    numbersListBox.Items.Add(temp);
                    total += temp;
                    numOfNumbers += 1;
                }

                // Close File
                inputFile.Close();

                // Puts results in text labels
                totalLabelText.Text = total.ToString();
                numberOfNumbersTextLabel.Text = numOfNumbers.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error reading file.");
            }
        }
    }
}
