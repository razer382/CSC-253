﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileReaderLib
{
    public class TryParse
    {
        public static int ParseInteger(string input)
        {
            if(int.TryParse(input, out int num))
            {
                return num;
            }
            else
            {
                MessageBox.Show("Error parsing integer.");
                return 0;
            }
        }
    }
}
